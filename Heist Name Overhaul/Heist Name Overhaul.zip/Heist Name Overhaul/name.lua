Hooks:Add("LocalizationManagerPostInit", "name", function(loc)
    LocalizationManager:add_localized_strings({
	--Bain
	heist_branchbank = "Bank:",
	heist_branchbank_cash = "Bank:",
	heist_branchbank_deposit = "Bank:",
	heist_branchbank_gold = "Bank:",
	heist_branchbank_hl = "Bank:",
	
	heist_cage = "Diesel Engine",
	heist_cage_hl = "Diesel Engine",
	
	heist_family = "Anna Rex",
	heist_family_hl = "Anna Rex",
	
	heist_gallery = "Rule34.xxx",
	heist_gallery_hl = "Rule34.xxx",
	
	heist_jewelry_store = "Not Ukrainian Job",
	heist_jewelry_store_hl = "Not Ukrainian Job",
	
	heist_kosugi = "Oda Nabunaga",
	heist_kosugi_hl = "Oda Nabunaga",
	
	heist_rat = "Hell's Kitchen",
	heist_rat_hl = "Hell's Kitchen",
	
	heist_roberts = "Stop Bank",
	heist_roberts_hl = "Stop Bank",
	
	heist_rvd = "Cistern Cats Heist",
	
	heist_arena = "Aleph-0",
	heist_arena_hl = "Aleph-0",
	
	heist_arm_for = "Transport: Level 1 Sentry",
	heist_arm_for_hl = "Transport: Level 1 Sentry",
	
	heist_arm_cro = "Transport: Four Roads",
	heist_arm_cro_hl = "Transport: Four Roads",
	
	heist_arm_hcm = "Transport: Downtown Bikini Bottom",
	heist_arm_hcm_hl = "Transport: Downtown Bikini Bottom",
	
	heist_arm_fac = "Transport: Pearl Harbor",
	heist_arm_fac_hl = "Transport: Pearl Harbor",
	
	heist_arm_und = "Transport: Overpass",
	heist_arm_und_hl = "Transport: Overpass",
	
	heist_arm_par = "Transport: Lame Park",
	heist_arm_par_hl = "Transport: Lame Park",
	
	--Classic
	heist_red2 = "Second World Bank",
	heist_red2_hl = "Second World Bank",
	
	heist_run = "Hot Road",
	heist_run_hl = "Hot Road",
	
	heist_dah = "Minecraft Heist",
	heist_dah_hl = "Minecraft Heist",
	
	heist_dinner = "Hog Rider",
	heist_dinner_hl = "Hog Rider",
	
	heist_flat = "Bile Sucks",
	heist_flat_hl = "Bile Sucks",
	
	heist_glace = "The Floor is Lava",
	heist_glace_hl = "The Floor is Lava",
	
	heist_man = "Overcover",
	heist_man_hl = "Overcover",
	
	heist_nmh = "Shoot the Tank",
	heist_nmh_hl = "Shoot the Tank",
	
	heist_pal = "Counterstrike CSGO",
	heist_pal_hl = "Counterstrike CSGO",
	
	--Events
	heist_help = "Brazil",
	heist_help_hl = "Brazil",
	
	heist_haunted = "Venezuela",
	heist_haunted_hl = "Venezuela",
	
	heist_nail = "Scary Meth",
	heist_nail_hl = "Scary Meth",
	
	heist_hvh = "Stupid",
	heist_hvh_hl = "Stupid",
	
	--Hector
	heist_alex = "Mouses",
	
	heist_watchdogs = "Kabosu",
	
	heist_firestarter = "Flint n Steel",
	
	--Jimmy
	heist_dark = "Subway Surfers",
	heist_dark_hl = "Subway Surfers",

	--Jiu Feng
	heist_chas = "Dragon Deez Nuts",
	heist_chas_hl = "Dragon Deez Nuts",
	
	heist_mad = "15 Killstreak EMP",
	heist_mad_hl = "15 Killstreak EMP",
	
	--Locke
	heist_pbr2 = "My Money Fell",
	heist_pbr2_hl = "My Money Fell",
	
	heist_brb = "Brooklyn",
	heist_brb_hl = "Brooklyn",
	
	heist_bph = "Bain Dies",
	heist_bph_hl = "Bain Dies",
	
	heist_des = "Patrick's Rock",
	heist_des_hl = "Patrick's Rock",
	
	heist_mex = "Cruzando el Borde",
	heist_mex_hl = "Cruzando el Borde",
	
	heist_mex_cooking = "Mexican Meth",
	heist_mex_cooking_hl = "Mexican Meth",
	
	heist_pbr = "Above the Hill",
	heist_pbr_hl = "Above the Hill",
	
	heist_pex = "Saw Skip",
	heist_pex_hl = "Saw Skip",
	
	heist_sah = "Luigi's Mansion",
	heist_sah_hl = "Luigi's Mansion",
	
	heist_tag = "Fixin' Feds",
	heist_tag_hl = "Fixin' Feds",
	
	heist_vit = "The Black House",
	heist_vit_hl = "The Black House",
	
	heist_wwh = "Alaskan Bull Worm",
	heist_wwh_hl = "Alaskan Bull Worm",
	
	--Butcher
	heist_crojob1 = "Cargo BTD6",
	heist_crojob2_hl = "Cargo BTD6",
	
	heist_crojob2 = "The Slope Zone",
	heist_crojob3_hl = "The Slope Zone",
	
	heist_friend = "Cool Mansion",
	heist_friend_hl = "Cool Mansion",
	
	--Continental
	heist_fish = "Hijacked",
	heist_fish_hl = "Hijacked",
	
	heist_spa = "Brooklyn 10-10-10-10-10-10-10-10-10-10-10-10-10-10-10",
	heist_spa_hl = "Brooklyn 10-10-10-10-10-10-10-10-10-10-10-10-10-10-10",
	
	--Dentist
	heist_mus = "The",
	heist_mus_hl = "The",
	
	heist_mia = "Hi By Krmal",
	
	heist_kenaz_full = "Money Casino No Gold",
	heist_kenaz_full_hl = "Money Casino No Gold",
	
	heist_hox = "Roblox Jailbreak",
	
	heist_hox_3 = "Rich House",
	heist_hox_3_hl = "Rich House",
	
	heist_big = "The Bank of Robloxia",
	heist_big_hl = "The Bank of Robloxia",
	
	--Elephant
	heist_born = "Stupid Swat Turret",
	
	heist_framing_frame = "The Gold is on the Otherside",
	
	heist_election_day = "Elections are Stupid",
	
	heist_welcome_to_the_jungle = "Small Oil",
	
	--Vlad
	heist_bex = "Third World Bank",
	heist_bex_hl = "Third World Bank",
	
	heist_mallcrasher = "No Russian",
	heist_mallcrasher_hl = "No Russian",
	
	heist_peta = "Anthrocon",
	
	heist_shoutout_raid = "Nukes!?!?",
	heist_shoutout_raid_hl = "Nukes!?!?",
	
	heist_ukrainian_job = "Not Jewelry Store",
	heist_ukrainian_job_hl = "Not Jewelry Store",
	
	heist_moon = "Stealing Robux",
	heist_moon_hl = "Stealing Robux",
	
	heist_cane = "December 24th",
	heist_cane_hl = "December 24th",
	
	heist_pines	 = "Pure Columbian",
	heist_pines_hl	 = "Pure Columbian",
	
	heist_jolly = "Free Safes and Skins",
	heist_jolly_hl = "Free Safes and Skins",
	
	heist_nightclub = "Mad City",
	heist_nightclub_hl = "Mad City",
	
	heist_four_stores = "Lego City",
	heist_four_stores_hl = "Lego City",
	
	heist_fex = "3D Shark Tank",
	heist_fex_hl = "3D Shark Tank",
	})
end)